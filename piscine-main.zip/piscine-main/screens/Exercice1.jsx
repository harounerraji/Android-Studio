import { Text, View } from "react-native";

export const Exercice1 = () => {
  return (
    <View>
      <Text>Exercice 1</Text>
    </View>
  );
};
