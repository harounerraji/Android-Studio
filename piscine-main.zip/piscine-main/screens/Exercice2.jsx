import ButtonComp from "../components/ButtonComp";

export const Exercice2 = () => {
  return <ButtonComp />;
};
